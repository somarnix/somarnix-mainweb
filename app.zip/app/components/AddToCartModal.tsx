// app\components\AddToCartModal.tsx
import { useState } from "react";
import { X, Plus, Minus, ShoppingCart } from "lucide-react";
import { Button } from "./ui/button";
import { useLanguage } from "../contexts/LanguageContext";
import { useCurrency } from "../contexts/CurrencyContext";
import { toast } from "sonner";

type ProductVariant = {
  id: number;
  label: string;        // e.g. "10 Days", "1 Month", "1 Year"
  price: number;
};

type Product = {
  id: number;
  title: string;
};

interface AddToCartModalProps {
  product: Product;
  variants: ProductVariant[];
  onClose: () => void;
}

export function AddToCartModal({
  product,
  variants,
  onClose,
}: AddToCartModalProps) {
  const { t, language } = useLanguage();
  const { formatPrice } = useCurrency();

  const [variantId, setVariantId] = useState<number>(variants[0]?.id);
  const [quantity, setQuantity] = useState(1);

  const selectedVariant = variants.find(v => v.id === variantId)!;
  const totalPrice = selectedVariant.price * quantity;

  const handleQuantityChange = (delta: number) => {
    setQuantity(Math.max(1, quantity + delta));
  };

  const handleAddToCart = async () => {
    const res = await fetch("/api/cart/add-cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        productId: product.id,
        variantId,
        qty: quantity,
      }),
    });

    if (!res.ok) {
      const data = await res.json();
      toast.error(data.error || "Add to cart failed");
      return;
    }

    toast.success("Added to cart");
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-md w-full">
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 border-b">
            <h3 className="font-bold">
              {t("modal.addToCart")}
            </h3>
            <button onClick={onClose}>
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-5 space-y-5">
            {/* Variant Selection */}
            <div>
              <label className="block text-sm font-semibold mb-3">
                {t("modal.selectDuration")}
              </label>

              <div className="space-y-2">
                {variants.map(v => (
                  <button
                    key={v.id}
                    onClick={() => setVariantId(v.id)}
                    className={`w-full p-4 rounded-lg border-2 flex justify-between ${
                      variantId === v.id
                        ? "border-blue-600 bg-blue-50 dark:bg-blue-900/20"
                        : "border-gray-200 dark:border-gray-700"
                    }`}
                  >
                    <span className="font-bold">
                      {v.label}
                    </span>
                    <span className="font-bold">
                      {formatPrice(v.price)}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-sm font-semibold mb-2">
                {t("modal.quantity")}
              </label>

              <div className="flex items-center gap-3">
                <div className="flex items-center border rounded-lg">
                  <button
                    onClick={() => handleQuantityChange(-1)}
                    disabled={quantity <= 1}
                    className="p-2"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="px-4 font-bold">{quantity}</span>
                  <button
                    onClick={() => handleQuantityChange(1)}
                    className="p-2"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex-1 text-right">
                  <div className="text-xs text-gray-500">
                    {t("modal.total")}
                  </div>
                  <div className="text-xl font-bold text-blue-600">
                    {formatPrice(totalPrice)}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="flex gap-3 px-5 py-4 bg-gray-50 dark:bg-gray-900 rounded-b-xl">
            <Button variant="outline" onClick={onClose} className="flex-1">
              {t("modal.close")}
            </Button>
            <Button
              onClick={handleAddToCart}
              className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              {t("modal.confirm")}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
}
