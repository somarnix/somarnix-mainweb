// app\page.tsx
"use client";

import App from "../app/App";

export default function Page() {
  return <App />;
}
