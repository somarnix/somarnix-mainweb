// app/api/cart/add-cart/route.ts
import { db } from "@/lib/db";
import { getAuthUser } from "@/lib/auth";
import type { RowDataPacket, ResultSetHeader } from "mysql2";

export async function POST(req: Request) {
  try {
    const auth = await getAuthUser(req);
    if (!auth) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const { productId, variantId, qty } = body;

    if (!productId || !variantId || !qty) {
      return Response.json({ error: "Missing fields" }, { status: 400 });
    }

    /* 1️⃣ Get or create cart */
    const [cartRows] = await db.query<RowDataPacket[]>(
      "SELECT id FROM carts WHERE user_id = ?",
      [auth.id]
    );

    let cartId: number;

    if (cartRows.length === 0) {
      const [res] = await db.query<ResultSetHeader>(
        "INSERT INTO carts (user_id) VALUES (?)",
        [auth.id]
      );
      cartId = res.insertId;
    } else {
      cartId = cartRows[0].id;
    }

    /* 2️⃣ Get variant price */
    const [variantRows] = await db.query<RowDataPacket[]>(
      "SELECT price FROM product_variants WHERE id = ? AND product_id = ?",
      [variantId, productId]
    );

    if (variantRows.length === 0) {
      return Response.json({ error: "Variant not found" }, { status: 404 });
    }

    const unitPrice = Number(variantRows[0].price);

    /* 3️⃣ Check existing cart item */
    const [itemRows] = await db.query<RowDataPacket[]>(
      "SELECT id, qty FROM cart_items WHERE cart_id = ? AND variant_id = ?",
      [cartId, variantId]
    );

    if (itemRows.length > 0) {
      await db.query(
        "UPDATE cart_items SET qty = qty + ? WHERE id = ?",
        [qty, itemRows[0].id]
      );
    } else {
      await db.query(
        `INSERT INTO cart_items 
         (cart_id, product_id, variant_id, qty, unit_price)
         VALUES (?, ?, ?, ?, ?)`,
        [cartId, productId, variantId, qty, unitPrice]
      );
    }

    return Response.json({ success: true });
  } catch (err) {
    console.error(err);
    return Response.json(
      { error: "Server error" },
      { status: 500 }
    );
  }
}
